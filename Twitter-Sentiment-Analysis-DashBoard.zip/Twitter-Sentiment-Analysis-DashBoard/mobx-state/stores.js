import GlobalState from './globalstate';

const stores = {
	globalstate: new GlobalState()
}


export default {
	...stores
}